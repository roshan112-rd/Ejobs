from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from .models import *
from django.contrib import messages, auth
from django.http import HttpResponseRedirect
from django.template import RequestContext

def seeker_register(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        email = request.POST['email']
        username = request.POST['username']
        
        contact = request.POST['contact']
        gender = request.POST['gender']
        address = request.POST['address']
        image = request.FILES['image']
        
        if password1 != password2:
            messages.info(request, 'passwords are different')
            return redirect('seeker_register')

        if User.objects.filter(username=username).exists():
            messages.info(request, 'username taken')
            return redirect('seeker_register')
           
        if User.objects.filter(email=email).exists():
            messages.info(request, 'email taken')
            return redirect('seeker_register')
        user = User.objects.create_user(username=username, password=password1, email=email, first_name=first_name, last_name=last_name)
        Seeker.objects.create(user=user, contact=contact, gender=gender, address=address, image=image)
        auth.login(request, user)
        return redirect('seeker_dashboard')
    else:
        return render(request, 'seeker/seeker_register.html')


def seeker_login(request):
    if request.method == "POST":
        username = request.POST['username']
        password1 = request.POST['password1']
        user = auth.authenticate(username=username, password=password1)
        if user is not None:
            seeker=Seeker.objects.get(user=user)
            if user.is_active:
                auth.login(request, user)
                return redirect('seeker_dashboard')
                auth.login(request, user)
            else:
                return render(request, 'login.html')
        else:
            messages.info(request, 'invalid credentials')
            return redirect('seeker_login')
    else:
        return render(request, 'seeker/seeker_login.html')
    

def seeker_dashboard(request):
    if request.user.is_authenticated:
        return render(request, 'seeker/seekerDashboard.html')
    else:
        messages.info(request, 'You are not logged in. Please log in to continue')
        return redirect('seeker_login')

def seeker_profile(request):
    if request.user.is_authenticated:
        userdata = Seeker.objects.filter(user=request.user)
        return render(request, 'seeker/profile.html', {'userdata': userdata})
    else:
        messages.info(request, 'You are not logged in. Please log in to continue')
        return redirect('home')


def recruiter_register(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        email = request.POST['email']
        username = request.POST['username']
        
        contact = request.POST['contact']
        address = request.POST['address']
        company_type=request.POST['company_type']
        company_name=request.POST['company_name']
        image = request.FILES['image']

        if password1 != password2:
            messages.info(request, 'passwords are different')
            return redirect('recruiter_register')

        if User.objects.filter(username=username).exists():
            messages.info(request, 'username taken')
            return redirect('recruiter_register')
           
        if User.objects.filter(email=email).exists():
            messages.info(request, 'email taken')
            return redirect('recruiter_register')

        user = User.objects.create_user(first_name=first_name, last_name=last_name, password=password1, email=email, username=username)
        Recruiter.objects.create(user=user, contact=contact, address=address,company_type=company_type,company_name=company_name, image=image)
        auth.login(request, user)
        return redirect('recruiter_dashboard')
    else:
        return render(request, 'recruiter/recruiter_register.html')
    

def recruiter_login(request):
    if request.method == "POST":
        username = request.POST['username']
        password1 = request.POST['password1']
        user = auth.authenticate(username=username, password=password1)
        if user is not None:
            recruiter=Recruiter.objects.get(user=user)
            if user.is_active:
                auth.login(request, user)
                
                return redirect('recruiter_dashboard')
                auth.login(request, user)
            else:
                return render(request, 'recruiter_login.html')
        else:
            messages.info(request, 'invalid credentials')
            return redirect('recruiter_login')
    else:
        return render(request, 'recruiter/recruiter_login.html')
    return render(request, 'recruiter/recruiter_login.html')

    
def recruiter_dashboard(request):
    if request.user.is_authenticated:
        return render(request, 'recruiter/recruiterDashboard.html')
    else:
        messages.info(request, 'You are not logged in. Please log in to continue')
        return redirect('recruiter_login')


def recruiter_profile(request):
    if request.user.is_authenticated:
        userdata = Recruiter.objects.filter(user=request.user)
        return render(request, 'recruiter/profile.html', {'userdata': userdata})
    else:
        messages.info(request, 'You are not logged in. Please log in to continue')
        return redirect('home')


def logout(request):
    auth.logout(request)
    messages.info(request, 'logged out successfully')
    return redirect('home')
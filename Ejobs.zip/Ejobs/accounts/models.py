from django.db import models
from django.contrib.auth.models import User
from PIL import Image


class Seeker(models.Model):    
    user= models.ForeignKey(User,on_delete=models.CASCADE)
    contact = models.CharField(max_length=15,null=True)
    gender = models.CharField(max_length=10, null=True)
    address = models.CharField(max_length=10, null=True)
    image = models.ImageField(blank=True,null=True, upload_to='seeker/', default='user.jpg')


    # def save(self, *args, **kwargs):
    #     super().save(*args, **kwargs)
    #     img=Image.open(self.image.path)
    #     if imag.height>300 or img.width>300:
    #         output_size=(300,300)
    #         img.thumbnail(output_size)
    #         img.save(self.image.path)



    def __str__(self):
        return self.user.username



class Recruiter(models.Model):    
    user= models.ForeignKey(User,on_delete=models.CASCADE)
    contact = models.CharField(max_length=15,null=True)
    address = models.CharField(max_length=100, null=True)
    company_type= models.CharField(max_length=100, null=True)
    company_name= models.CharField(max_length=100, null=True)
    image = models.ImageField(blank=True, null=True, upload_to='seeker/')
    def __str__(self):
        return self.user.username